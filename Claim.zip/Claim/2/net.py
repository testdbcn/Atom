import aiohttp
import asyncio
import json
from tqdm import tqdm

# Endpoints
CLAIM_LIST_URL = "https://store.atom.com.mm/mytmapi/v1/my/point-system/claim-list"
CLAIM_URL = "https://store.atom.com.mm/mytmapi/v1/my/point-system/claim"
DASHBOARD_URL = "https://store.atom.com.mm/mytmapi/v1/my/dashboard"

COMMON_HEADERS = {
    "User-Agent": "MyTM/4.11.0/Android/30",
    "X-Server-Select": "production",
    "Device-Name": "Xiaomi Redmi Note 8 Pro"
}

async def fetch_json_data(session, api_url, db_id):
    try:
        async with session.get(api_url, headers=COMMON_HEADERS) as response:
            if response.status == 200:
                data = await response.json()
                backup_file = f"backup_{db_id}.json"
                with open(backup_file, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=4)
                return data
            return None
    except Exception:
        return None

async def get_claimable_id(session, access_token, msisdn, userid):
    params = {
        "msisdn": msisdn.replace("%2B959", "+959"),
        "userid": userid,
        "v": "4.11.0"
    }
    headers = {**COMMON_HEADERS, "Authorization": f"Bearer {access_token}"}
    try:
        async with session.get(CLAIM_LIST_URL, params=params, headers=headers) as response:
            if response.status == 200:
                json_data = await response.json()
                attributes = json_data.get("data", {}).get("attribute", [])
                for attribute in attributes:
                    if attribute.get("enable", False):
                        return str(attribute.get("id", "no"))
                return "no"
            return "error"
    except Exception:
        return "error"

async def process_claim(session, access_token, msisdn, userid, claim_id):
    params = {
        "msisdn": msisdn.replace("%2B959", "+959"),
        "userid": userid,
        "v": "4.11.0"
    }
    headers = {**COMMON_HEADERS, "Authorization": f"Bearer {access_token}"}
    payload = {"id": int(float(claim_id))}  # Handle Java's double parsing logic
    try:
        async with session.post(CLAIM_URL, params=params, json=payload, headers=headers) as response:
            return response.status == 200
    except Exception:
        return False

async def handle_claim(session, item):
    msisdn = item["phone"]
    access_token = item["access"]
    userid = item["userid"]
    claim_id = await get_claimable_id(session, access_token, msisdn, userid)
    # If error or "no" available id, treat as no claim found.
    if claim_id in ["no", "error"]:
        return False
    return await process_claim(session, access_token, msisdn, userid, claim_id)

async def send_dashboard_request(session, item):
    params = {
        "isFirstTime": "1",
        "isFirstInstall": "0",
        "msisdn": item["phone"].replace("%2B959", "+959"),
        "userid": item["userid"],
        "v": "4.11.0"
    }
    headers = {**COMMON_HEADERS, "Authorization": f"Bearer {item['access']}"}
    try:
        async with session.get(DASHBOARD_URL, params=params, headers=headers) as response:
            return "Success" if response.status == 200 else "Fail"
    except Exception:
        return "Fail"

async def process_item(session, item, pbar, counters, no_claim_file, fail_file):
    phone = item["phone"]
    dashboard_status = await send_dashboard_request(session, item)
    claim_result = await handle_claim(session, item)
    
    # Update counters
    counters["total"] += 1
    if dashboard_status == "Success":
        counters["dash_success"] += 1
    else:
        counters["dash_fail"] += 1
    if claim_result:
        counters["claim_found"] += 1
    else:
        counters["claim_not_found"] += 1

    # Write to files if claim not found or dashboard fails.
    if not claim_result:
        no_claim_file.write(json.dumps(item) + "\n")
        no_claim_file.flush()
    if dashboard_status == "Fail":
        fail_file.write(json.dumps(item) + "\n")
        fail_file.flush()

    # Update progress bar and log this phone
    pbar.update(1)
    pbar.set_postfix({
        "Dash_Success": counters["dash_success"],
        "Dash_Fail": counters["dash_fail"],
        "Claim_Found": counters["claim_found"],
        "Claim_NotFound": counters["claim_not_found"],
        "Total": counters["total"]
    })
    pbar.write(f"{phone} | Dashboard: {dashboard_status} | Claim: {'Found' if claim_result else 'Not Found'}")
    return (dashboard_status, claim_result)

async def process_api_requests_for_db(db_id, pbar, counters, no_claim_file, fail_file):
    api_url = f"http://150.95.26.171/v2/get/?r={db_id}"
    pbar.write(f"Fetching DB: {db_id}")
    async with aiohttp.ClientSession() as session:
        json_data = await fetch_json_data(session, api_url, db_id)
        if not json_data:
            return
        # Increase total tasks count by number of items in this DB.
        pbar.total += len(json_data)
        pbar.refresh()
        tasks = [process_item(session, item, pbar, counters, no_claim_file, fail_file) for item in json_data]
        await asyncio.gather(*tasks)

async def run_all():
    counters = {
        "total": 0,
        "dash_success": 0,
        "dash_fail": 0,
        "claim_found": 0,
        "claim_not_found": 0
    }
    # Open the files to log "no claim found" and "fail" items.
    with open("no_claim_found.txt", "w") as no_claim_file, open("fail.txt", "w") as fail_file:
        with tqdm(total=0, desc="Processing phones", dynamic_ncols=True) as pbar:
            for db_id in range(1, 31):
                await process_api_requests_for_db(db_id, pbar, counters, no_claim_file, fail_file)
            pbar.close()
    # Final summary
    print(f"\nFinal Summary -> Total Process: {counters['total']}, Dashboard Success: {counters['dash_success']}, "
          f"Dashboard Fail: {counters['dash_fail']}, Claim Found: {counters['claim_found']}, "
          f"Claim Not Found: {counters['claim_not_found']}")

if __name__ == "__main__":
    asyncio.run(run_all())
