import asyncio
import aiohttp
import os
from tqdm.asyncio import tqdm_asyncio

# API URLs
fetch_url = "http://68.183.184.13/v2/phone"
send_url = "http://68.183.184.13/v2/refresh/"

# Configuration
MAX_CONCURRENT_REQUESTS = 500
CONNECTION_TIMEOUT = 30
CONNECTION_POOL_SIZE = MAX_CONCURRENT_REQUESTS

# Global state
success_count = 0
fail_count = 0
error_log = []
counter_lock = asyncio.Lock()

async def async_input(prompt):
    """Asynchronous input prompt."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, input, prompt)

async def fetch_numbers():
    """Fetch phone numbers from API."""
    timeout = aiohttp.ClientTimeout(total=CONNECTION_TIMEOUT)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(fetch_url) as response:
            if response.status == 200:
                return await response.json()
            print(f"Fetch failed: {response.status}")
            return []

async def process_number(session, phone):
    """Process a single phone number."""
    global success_count, fail_count, error_log
    url = f"{send_url}?phone={phone}"
    
    try:
        async with session.get(url) as response:
            async with counter_lock:
                if response.status == 200:
                    success_count += 1
                else:
                    fail_count += 1
                    error_log.append(phone)
                return response.status
    except Exception as e:
        async with counter_lock:
            fail_count += 1
            error_log.append(phone)
        return str(e)

async def worker(session, queue, progress):
    """Worker process for concurrent handling."""
    while True:
        phone = await queue.get()
        try:
            await process_number(session, phone)
        finally:
            queue.task_done()
            progress.update()

async def process_batch(numbers, batch_name="Processing"):
    """Process a batch of numbers with progress tracking."""
    global error_log
    total = len(numbers)
    if total == 0:
        return

    connector = aiohttp.TCPConnector(limit=MAX_CONCURRENT_REQUESTS)
    client_timeout = aiohttp.ClientTimeout(total=CONNECTION_TIMEOUT)

    async with aiohttp.ClientSession(
        connector=connector,
        timeout=client_timeout
    ) as session:
        queue = asyncio.Queue(maxsize=MAX_CONCURRENT_REQUESTS * 2)
        
        with tqdm_asyncio(total=total, desc=batch_name, unit="req") as progress:
            workers = [
                asyncio.create_task(worker(session, queue, progress))
                for _ in range(MAX_CONCURRENT_REQUESTS)
            ]
            
            for phone in numbers:
                await queue.put(phone)
            
            await queue.join()
            
            for task in workers:
                task.cancel()
            await asyncio.gather(*workers, return_exceptions=True)

async def main():
    global success_count, fail_count, error_log

    # Initial processing
    initial_numbers = await fetch_numbers()
    if not initial_numbers:
        print("No numbers to process.")
        return

    error_log.clear()
    await process_batch(initial_numbers, "Initial batch")

    print("\nInitial processing complete!")
    print(f"✅ Success: {success_count}")
    print(f"❌ Failed: {fail_count}")
    
    if error_log:
        with open("failed_requests.txt", "w") as f:
            f.writelines(f"{phone}\n" for phone in error_log)
        print(f"⚠️ Saved {len(error_log)} failures to failed_requests.txt")

    # Retry loop
    while True:
        if not os.path.exists("failed_requests.txt"):
            break
            
        with open("failed_requests.txt", "r") as f:
            retry_numbers = [line.strip() for line in f if line.strip()]
            
        if not retry_numbers:
            os.remove("failed_requests.txt")
            break

        retry = await async_input("\nRetry failed requests? (y/n): ")
        if retry.lower() != 'y':
            break

        # Clear previous errors for new retry
        error_log.clear()
        await process_batch(retry_numbers, "Retrying failed")
        
        if error_log:
            with open("failed_requests.txt", "w") as f:
                f.writelines(f"{phone}\n" for phone in error_log)
            print(f"⚠️ {len(error_log)} requests failed during retry")
        else:
            if os.path.exists("failed_requests.txt"):
                os.remove("failed_requests.txt")
            print("🎉 All retried requests succeeded!")
        
        print(f"Current totals: ✅ {success_count} | ❌ {fail_count}")

    print("\nFinal results:")
    print(f"Total successes: {success_count}")
    print(f"Total failures: {fail_count}")

if __name__ == "__main__":
    asyncio.run(main())